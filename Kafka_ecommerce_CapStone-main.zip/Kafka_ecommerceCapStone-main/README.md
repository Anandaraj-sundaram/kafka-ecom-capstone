Kumar Sarthak..
1781397....
 Kafka based project using java.
 We consume and push products to mysql once we get in consumer.
